#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#
function log_auto_dele(){  
    local logfile=$1  
    local maxline=$2 


    linecount=$(/usr/bin/wc -l $logfile | awk '{print $1}')
    if [ ${linecount} -gt ${maxline} ];then  
       echo "" > $logfile
    else    
        echo  $linecount
    fi
}

# running
log_auto_dele /tmp/upload/merlinclash_node_mark.log 120



